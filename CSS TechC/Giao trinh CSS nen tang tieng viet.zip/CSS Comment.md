Nhận xét được sử dụng để giải thích mã và có thể hữu ích khi bạn chỉnh sửa mã nguồn vào một ngày sau đó.

Các bình luận bị trình duyệt bỏ qua.

Nhận xét CSS được đặt bên trong style phần tử và bắt đầu bằng /* và kết thúc bằng */


VD : 
/* This is a single-line comment */
p {
  color: red;
}

p {
  color: red;  /* Set text color to red */
}

+ Nhận xét cũng có thể kéo dài nhiều dòng: 

VD : 
/* This is
a multi-line
comment */
p {
  color: red;
}
I . Một số thuộc tính chính của font

        + font-family
        + font-size
        + font-weight
        + font-style

1 .font-family

+ font-family là thuộc tính quyết định loại font nào sẽ được áp dụng

2 .font-size

+ font-size là thuộc tính dùng để thiết lập kích cỡ của chữ

+ Mình có thể thiết lập giá trị cho font-size với nhiều kiểu khác nhau như px, pt, em...

Lưu ý: Nếu bạn không chỉ rõ font-size là bao nhiêu thì mặc định nó hiển thị như chữ bình thường là 16px

3 .font-weight

+ font-weight là thuộc tính dùng để thiết lập độ đậm của chữ.

font-weight có thể sử dụng một trong hai loại sau:
        
Bằng số: 100, 200, 300, 400, 500, 600, 700, 800, 900
Bằng chữ: normal, bold, lighter....
Trong đó:

normal: chữ sẽ hiển thị bình thường, đây cũng là giá trị mặc định và tương đương với 400.
bold: chữ sẽ hiển thị  đậm, tương đương 700.
bolder: chữ cái sẽ đậm hơn phần tử cha của nó.
lighter: chữ cái sẽ nhạt hơn chữ cái của phần tử cha

4 .font-style
+ font-style là thuộc tính dùng để thiết lập chữ in thường hoặc in nghiêng, đơn giản vậy thôi : normal là viết thường , italic là viết nghiêng



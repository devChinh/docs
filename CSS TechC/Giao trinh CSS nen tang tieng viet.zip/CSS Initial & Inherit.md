1 Initial

+ Từ khoá initial được sử dụng để đặt thuộc tính CSS thành giá trị mặc định của nó.
+ Từ khoá initial có thể được sử dụng cho bất kỳ thuộc tính CSS nào và trên bất kỳ phần tử HTML nào

2 Inherit

+ Từ khoá inherit chỉ định rằng một thuộc tính sẽ kế thừa giá trị của nó từ phần tử mẹ của nó.
+ Từ khoá inherit có thể được sử dụng cho bất kỳ thuộc tính CSS nào và trên bất kỳ phần tử HTML nào.
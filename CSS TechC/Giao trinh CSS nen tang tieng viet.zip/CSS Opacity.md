1 Opacity 

Thuộc tính opacity chỉ định độ mờ / trong suốt của một phần tử
Thuộc tính opacity có thể nhận giá trị từ 0,0 - 1,0 , giá trị càng thấp thì càng mờ

- Hiệu ứng Di chuột trong suốt
Thuộc tính opacity thường được sử dụng cùng với :hover bộ chọn để thay đổi độ mờ khi di chuột qua

- Khi sử dụng thuộc tính opacity để thêm độ trong suốt vào nền của một phần tử, tất cả các phần tử con của nó sẽ kế thừa cùng một độ trong suốt. Điều này có thể làm cho văn bản bên trong một phần tử hoàn toàn trong suốt khó đọc nhưng cũng không phải là vấn đề gì lớn lắm vì hầu như khi sử dụng opacity thì ngta sẽ dùng kèm theo với :hover để người dùng di chuột qua thì mới ăn opacity thôi 





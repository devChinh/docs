1. Border là gì?
Border là thuộc tính CSS dùng để tạo đường viền bao quanh nội dung của phần tử HTML

2. Các thuộc tính của border
        + border-style
        + border-width
        + border-color
        + border-radius

 - border-style : 
border-style là thuộc tính để thiết lập loại border nào sẽ được hiển thị.

Những style chính là border hổ trợ như sau:

        + dotted - border sẽ hiển thị là những dấu chấm
        + dashed - border sẽ hiển thị nét đứt
        + solid - border sẽ hiển thị đường thẳng liền mạch
        + double - border sẽ hiển thị 2 đường thẳng
        + groove - border sẽ hiển thị dạng rãnh 3D.
        + ridge - border sẽ hiển thị dạng viền 3D.
        + inset - border sẽ hiển thị dạng viền trong 3D. 
        + outset - border sẽ hiển thị dạng viền đầu 3D. 
        + none - sẽ không có border
        + hidden - border sẽ  bị ẩn.

- border-width
border-width là thuộc tính để thiết lập độ rộng của border ,  có thể sử dụng CSS Unit như pt, px, em, rem ..

- border-color
border-color là thuộc tính để thiết lập màu sắc cho border.

Color có thể có giá trị là name, rgb, hex..

- border-radius
border-radius là để thiết lập bo tròn cho border

3. Border Shorthand
Border shorthand là cách viết ngắn gọn cho 3 thuộc tính border-width, border-style và border-color.

Cú pháp CSS:
selector {
      border: width style color;
}



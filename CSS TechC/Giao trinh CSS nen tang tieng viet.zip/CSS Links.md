I .Các thuộc tính CSS định dạng thẻ a (links)
Thẻ a đóng vai trò rất quan trọng vì nhiệm vụ của nó là giúp chuyển trang giữa các file trong hệ thống website.

Mỗi website sẽ có nhiều thẻ a và  muốn bắt mắt với người dùng thì buộc phải style cho nó như xác định chiều cao, độ lớn chữ, màu sắc, hover, ....

Nội dung như sau:

+ Chọn màu sắc
+ Làm việc với text-decoration
+ Thiết lập background
+ Style các sự kiện (hover, visited, link, active)
+ Trong phần này mình có sử dụng kiến thức của bài cũ như color, text-decoration

1. Chọn màu sắc cho thẻ a
Mặc định thẻ a nó có màu tím tím nên để chọn màu sắc thì bạn sẽ nhớ đến thuộc tính color và selector của thẻ a thì chính là tên của nó luôn a

2. Tắt gạch chân thẻ a với text-decoration
Thông thường khi  tạo thẻ a thì theo mặc định nó có gạch chân nên để tắt gạch chân thì bạn sử dụng thuộc tính text-decoration:none

3. Chọn background cho thẻ a
Cũng tương tự các phần trên ta sẽ sử dụng một thuộc tính chuyên về CSS background đó là background

4. Style các sự kiện (hover, visited, active, link)
Các sự kiện này xay ra khi chúng ta dùng chuột thao tác lên nó.

        + hover: Khi  hover chuột qua nó sẽ có tác dụng
        + visited: khi  click vào thẻ a  , một liên kết mà người dùng đã truy cập
        + active: Khi click vào thẻ a nhưng nhấn giữ chuột
        + link: thẻ a nào  chưa click lần nào thì nó sẽ có tác dụng ( mặc định khi hiển thị )




